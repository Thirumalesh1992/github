package com.test.github.service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class GithubService {

	private String getResponse(String url) {
		HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .build();

        HttpResponse<String> response;
		try {
			response = client.send(request,
			        HttpResponse.BodyHandlers.ofString());
			return response.body();
		} catch(Exception e) {
			System.out.println("Error getting "+url);
			e.printStackTrace();
			throw new Error("Error getting data "+e.getMessage());
		}
	}
	
	public String getUser(String userName) {
		String userUrl = "https://api.github.com/users/" + userName;
		return getResponse(userUrl);
	}
	
	public String getRepos(String userName) {
		String repoUrl = "https://api.github.com/users/" + userName+"/repos";
		return getResponse(repoUrl);
	}
	public List<Map<String, Object>> getPulls(String userName) throws JsonMappingException, JsonProcessingException {
		String reposStr = getRepos(userName);
		ObjectMapper mapper = new ObjectMapper();
		List<Map<String, Object>> repoList = mapper.readValue(reposStr, new TypeReference<List<Map<String, Object>>>(){});
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		for(Map<String, Object> repo: repoList) {

			String repoName = (String) repo.get("name");
			String commitsUrl = "https://api.github.com/repos/" + userName+"/"+repoName+"/pulls";
			String commitStr = getResponse(commitsUrl);
			List<Map<String, Object>> commitsList = mapper.readValue(commitStr, new TypeReference<List<Map<String, Object>>>(){});
			result.addAll(commitsList);
		}
		return result;
	}
	
	public List<Map<String, Object>> getCommits(String userName) throws JsonMappingException, JsonProcessingException {
		String reposStr = getRepos(userName);
		ObjectMapper mapper = new ObjectMapper();
		List<Map<String, Object>> repoList = mapper.readValue(reposStr, new TypeReference<List<Map<String, Object>>>(){});
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		for(Map<String, Object> repo: repoList) {
		
			String repoName = (String) repo.get("name");
			String commitsUrl = "https://api.github.com/repos/" + userName+"/"+repoName+"/commits";
			String commitStr = getResponse(commitsUrl);
			List<Map<String, Object>> commitsList = mapper.readValue(commitStr, new TypeReference<List<Map<String, Object>>>(){});
			result.addAll(commitsList);
		}
		return result;
	}
}
