package com.test.github.rest;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.github.service.GithubService;

@RestController
@RequestMapping("api/v1/github")
public class RestGithubUserAPI {
	
	@Autowired
	private GithubService githubService;
	
	@RequestMapping(value = "/user", method = RequestMethod.GET,produces = "application/json")
	public ResponseEntity<String> user(@RequestParam("userName") String userName) {
		try {
			String response = githubService.getUser(userName);
			return new ResponseEntity(response, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping(value = "/repos", method = RequestMethod.GET,produces = "application/json")
	public ResponseEntity<String> repos(@RequestParam("userName") String userName) {
		try {
			String response = githubService.getRepos(userName);
			return new ResponseEntity(response, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping(value = "/commits", method = RequestMethod.GET,produces = "application/json")
	public ResponseEntity<String> commits(@RequestParam("userName") String userName) {
		try {
			List<Map<String, Object>> response = githubService.getCommits(userName);
			return new ResponseEntity(response, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@RequestMapping(value = "/pulls", method = RequestMethod.GET,produces = "application/json")
	public ResponseEntity<String> pulls(@RequestParam("userName") String userName) {
		try {
			List<Map<String, Object>> response = githubService.getPulls(userName);
			return new ResponseEntity(response, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
}
